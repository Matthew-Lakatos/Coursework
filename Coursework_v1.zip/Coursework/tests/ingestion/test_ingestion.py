import json

import pytest

from application.ingestion.detector import (
    Detector,
    FileFormat
)
from application.ingestion.errors import (
    BinaryFileError,
)
from application.ingestion.service import (
    IngestionService,
)

def test_csv_ingestion_and_type_inference(
        tmp_path
):
    file = tmp_path / "students.csv"

    file.write_text(
        "Name,Age,Passed,Score\n"
        "Bob,23,true,60\n"
        "Charlie,32,false,40\n"
        "Daniel,20,true,70\n"
        "Emma,35,false,30\n",
        encoding="utf-8"
    )

    dataset = IngestionService().ingest_one(
        file
    )

    assert dataset.source_format == "csv"
    assert len(dataset.rows) == 4
    assert len(dataset.schema.columns) == 4

def test_mislabelled_csv(
        tmp_path
):
    file = tmp_path / "students.txt"

    file.write_text(
        "Name,Age,Score\n"
        "Alice,20,20\n"
        "Bob,21,30\n",
        encoding="utf-8"
    )

    result = Detector().detect(file)

    assert result.format == FileFormat.CSV

def test_json_ingestion(
        tmp_path
):
    file = tmp_path / "students.json"

    data = [
        {
            "name": "Alice",
            "age": 16,
            "score": 82
         },
         {
             "name": "Bob",
             "age": 17,
             "score": 74
         }
    ]

    file.write_text(
        json.dumps(data),
        encoding = "utf-8"
    )

    dataset = IngestionService().ingest_one(
        file
    )

    assert dataset.source_format == "json"
    assert len(dataset.rows) == 2
    assert len(dataset.schema.columns) == 3

def test_binary_file_is_rejected(
    tmp_path
):
    file = tmp_path / "data.bin"

    file.write_bytes(
        b"\x00\x01\x02\x03"
    )

    with pytest.raises(BinaryFileError):
        Detector().detect(file)

def test_ragged_csv_rows_preserve_missing_data(
        tmp_path
):
    file = tmp_path / "scores.csv"

    file.write_text(
        "Name,Age,Score\n"
        "Alice,23,34\n"
        "Bob,24\n",
        encoding = "utf-8"
    )

    dataset = IngestionService().ingest_one(
        file
    )

    Bob = dataset.rows[1]

    assert Bob.values[0] == "Bob"
    # values are kept as parsed (strings); type inference only labels the column
    assert Bob.values[1] == "24"
    assert Bob.values[2] is None