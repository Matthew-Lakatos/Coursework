from application.ingestion import (
    IngestionService,
)
from application.validation import (
    Validator,
)

def test_valid_dataset_passes(
        tmp_path
):
    file = tmp_path / "data.csv"

    file.write_text(
        "Names,Score\n"
        "Alice,20\n"
        "Bob,30\n",
        encoding="utf-8"
    )

    dataset = IngestionService().ingest_one(
        file
    )

    result = Validator().validate(dataset)

    assert result.valid
    assert not (result.issues)
