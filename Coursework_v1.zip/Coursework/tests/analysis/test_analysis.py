import pytest

from application.analysis import (
    AnalysisEngine,
    OperationRegistry,
)
from application.ingestion import (
    IngestionService,
)

def test_mean(
    tmp_path
):

    file = tmp_path / "Scores.csv"
    file.write_text("Name, Score\n" "Alice, 80\n" "Bob, 60\n" "Charlie, 70.5\n" "David, 69.5", encoding="utf-8")

    dataset = IngestionService().ingest_one(
        file
    )

    result = AnalysisEngine().execute(
        "mean",
        dataset,
        column = "Score"
    )

    assert (result.value == 70)

def test_range(
    tmp_path
):

    file = tmp_path / "Scores.csv"
    file.write_text("Name, Score\n" "Alice, 80\n" "Bob, 60\n" "Charlie, 70.5\n" "David, 69.5", encoding="utf-8")

    dataset = IngestionService().ingest_one(
        file
    )

    result = AnalysisEngine().execute(
        "range",
        dataset,
        column = "Score"
    )

    assert (result.value == 20)

def test_correlation_zero_variance_is_rejected(
    tmp_path
):

    file = tmp_path / "Scores.csv"
    file.write_text("A, B\n" "10, 10\n" "10, 20\n" "10, 30\n" "10, 40", encoding="utf-8")

    dataset = IngestionService().ingest_one(
        file
    )

    with pytest.raises(ValueError, match="zero variance"):

        AnalysisEngine().execute(
            "correlation",
            dataset,
            column_x = "A",
            column_y = "B"
        )

def test_spearman_is_registered():

    assert "spearman" in OperationRegistry().names()

def test_spearman_perfect_monotonic_relationship(
    tmp_path
):

    # monotonic but not linear: pearson < 1, spearman == 1
    file = tmp_path / "Scores.csv"
    file.write_text("X, Y\n" "1, 1\n" "2, 8\n" "3, 27\n" "4, 64\n" "5, 125", encoding="utf-8")

    dataset = IngestionService().ingest_one(
        file
    )

    result = AnalysisEngine().execute(
        "spearman",
        dataset,
        column_x = "X",
        column_y = "Y"
    )

    assert (result.value == 1.0)

    pearson = AnalysisEngine().execute(
        "correlation",
        dataset,
        column_x = "X",
        column_y = "Y"
    )

    assert (pearson.value < 1.0)

def test_spearman_perfect_inverse_relationship(
    tmp_path
):

    file = tmp_path / "Scores.csv"
    file.write_text("X, Y\n" "1, 50\n" "2, 40\n" "3, 30\n" "4, 20", encoding="utf-8")

    dataset = IngestionService().ingest_one(
        file
    )

    result = AnalysisEngine().execute(
        "spearman",
        dataset,
        column_x = "X",
        column_y = "Y"
    )

    assert (result.value == -1.0)

def test_spearman_handles_ties(
    tmp_path
):

    # reference value from scipy.stats.spearmanr([1, 2, 3, 4, 5], [5, 6, 7, 8, 7])
    file = tmp_path / "Scores.csv"
    file.write_text("X, Y\n" "1, 5\n" "2, 6\n" "3, 7\n" "4, 8\n" "5, 7", encoding="utf-8")

    dataset = IngestionService().ingest_one(
        file
    )

    result = AnalysisEngine().execute(
        "spearman",
        dataset,
        column_x = "X",
        column_y = "Y"
    )

    assert (result.value == pytest.approx(0.8207826816681233))

def test_spearman_zero_variance_is_rejected(
    tmp_path
):

    file = tmp_path / "Scores.csv"
    file.write_text("A, B\n" "10, 10\n" "10, 20\n" "10, 30\n" "10, 40", encoding="utf-8")

    dataset = IngestionService().ingest_one(
        file
    )

    with pytest.raises(ValueError, match="zero variance"):

        AnalysisEngine().execute(
            "spearman",
            dataset,
            column_x = "A",
            column_y = "B"
        )

def test_spearman_requires_two_values(
    tmp_path
):

    file = tmp_path / "Scores.csv"
    file.write_text("A, B\n" "1, 2", encoding="utf-8")

    dataset = IngestionService().ingest_one(
        file
    )

    with pytest.raises(ValueError, match="At least two values"):

        AnalysisEngine().execute(
            "spearman",
            dataset,
            column_x = "A",
            column_y = "B"
        )
