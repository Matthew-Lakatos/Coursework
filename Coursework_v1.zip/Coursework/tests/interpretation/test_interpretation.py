from application.interpretation import (
    PromptProcessor,
)

def test_interpretation():

    intent = PromptProcessor().interpret(
        "What is the average score?"
    )

    assert intent.operation == "mean"
    assert intent.parameters == {"column": "score"}
    assert intent.confidence >= 0.9

def test_unknown_prompt_requires_llm():

    intent = PromptProcessor().interpret(
        "How did they do?"
    )

    assert intent.operation == "unknown"
    assert intent.requires_llm

def test_spearman_prompt():

    intent = PromptProcessor().interpret(
        "What is the Spearman correlation between Score and Attendance?"
    )

    assert intent.operation == "spearman"
    assert intent.parameters == {
        "column_x": "Score",
        "column_y": "Attendance"
    }

def test_pearson_prompt_still_maps_to_correlation():

    intent = PromptProcessor().interpret(
        "What is the correlation between Score and Attendance?"
    )

    assert intent.operation == "correlation"
    assert intent.parameters == {
        "column_x": "Score",
        "column_y": "Attendance"
    }
