from application.ingestion.service import (
    IngestionService,
)
from application.instances import (
    InstanceManager,
)


def test_instance_create_and_retrieve(
    tmp_path
):

    file = tmp_path / "data.csv"

    file.write_text(
        "Name,Score\n"
        "Alice,80\n",
        encoding="utf-8"
    )

    dataset = IngestionService().ingest_one(
        file
    )

    manager = InstanceManager()

    instance = manager.create(
        dataset,
        name="Year 10 Test"
    )

    retrieved = manager.retrieve(
        instance.id
    )

    assert retrieved.id == instance.id
    assert retrieved.name == "Year 10 Test"
    assert len(retrieved.datasets) == 1