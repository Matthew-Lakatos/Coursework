from application.security import (
    LocalAuthenticator,
)

print("starting authentication tests...")

def test_password_authentication():

    auth = LocalAuthenticator()

    user = auth.create_user(
        "teacher",
        "true-password"
    )

    assert auth.authenticate(
        "teacher",
        "true-password"
    )

    assert not auth.authenticate(
        "teacher",
        "false-password"
    )

def test_password_is_not_stored_plaintext():

    auth = LocalAuthenticator()

    user = auth.create_user(
        "teacher",
        "true-password"
    )

    assert (
        user.password_hash != "true-password"
    )

    assert (
        '$' in user.password_hash
    )