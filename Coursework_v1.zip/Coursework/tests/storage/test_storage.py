from application.storage import (
    ContextItem,
    ContextLog,
)
from datetime import datetime

def test_context_retrieval_by_tag():

    log = ContextLog()

    log.add(

        ContextItem(
            id="1",
            instance_id = "test",
            timestamp = datetime.now(),
            tags=("score", "mean"),
            content={
                "value": "72"
            }
        )

    )

    log.add(

        ContextItem(
            id="2",
            instance_id = "test",
            timestamp = datetime.now(),
            tags = ("attendance", ),
            content = {
                "value": "94"
            }
        )

    )

    result = log.retrieve(
        "test",
        tags = {"score"}
    )

    assert (len(result) == 1)
    assert (result[0].id == "1")
