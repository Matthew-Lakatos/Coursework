from dataclasses import dataclass, field
from datetime import date, datetime
from enum import Enum
from typing import Any

class ValueType(str, Enum):
    NUMERIC = "numeric"
    DATE = "date"
    BOOLEAN = "boolean"
    CATEGORICAL = "categorical"
    TEXT = "text"
    UNKNOWN = "unknown"

@dataclass(frozen=True) #immutable representation
class ParsedTable:
    #intermediate representation
    headers: list[str]
    rows: list[list[Any]]
    source_format: str
    sheet_name: str | None = None

@dataclass(frozen=True)
class Column:
    name: str
    value_type: ValueType
    nullable: bool = True #default

@dataclass(frozen=True)
class Row:
    values: tuple[Any, ...]

@dataclass(frozen=True)
class Schema:
    columns: tuple[Column, ...]

    def column_names(self) -> tuple[str, ...]:
        return tuple(column.name for column in (self.columns))

    def index_of(self, name: str) -> int:
        names = self.column_names()

        if name not in names:
            raise KeyError(name)

        return names.index(name)

@dataclass(frozen=True)
class Dataset: #common data representation, future-compatible design
    schema: Schema
    rows: tuple[Row, ...]
    source: str
    source_format: str
    metadata: dict[str, Any] = field(
        default_factory = dict
    )

    @property
    def row_count(self) -> int:
        return len(self.rows)

    @property
    def column_count(self) -> int:
        return len(self.schema.columns)

    def column_values(self, column_name: str) -> list[Any]:
        index = self.schema.index_of(column_name)

        return [
            row.values[index] for row in self.rows
        ]

    def as_records(self) -> list[dict[str, Any]]:
        names = self.schema.column_names()

        return [dict(zip(names, row.values)) for row in self.rows]