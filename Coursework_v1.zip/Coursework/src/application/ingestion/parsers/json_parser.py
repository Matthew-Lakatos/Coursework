import json
from pathlib import Path
from typing import Any

from ...representation.models import ParsedTable
from .base import Parser

class JSONParser(Parser):

    def parse(
            self,
            path: Path
    ) -> list[ParsedTable]:
        with path.open("r", encoding = "utf-8-sig") as file:
            try:
                data = json.load(file)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"Malformed JSON file: {path}"
                ) from exc

        if isinstance(data, list):
            return [self._parse_list(data)]

        if isinstance(data, dict):
            return [self._parse_dict(data)]

        raise ValueError(
            "JSON must contain object or array."
        )

    def _parse_list(self, data: list[Any]) -> ParsedTable:
        if not (data):
            return ParsedTable(
                headers=[],
                rows=[],
                source_format="json"
            )

        if all(
            isinstance(item, dict) for item in data
        ):
            headers = []

            for item in data:
                for key in item.keys():

                    if key not in headers:
                        headers.append(key)

            rows = [
                [
                    item.get(header) for header in headers
                ] for item in data
            ]

            return ParsedTable(headers=headers, rows=rows, source_format = "json")

        if all(isinstance(item, list) for item in data):
            return ParsedTable(headers=[],rows=data,source_format="json")

        #simple list

        return ParsedTable(
            headers=["value"],
            rows = [
                [item] for item in data
            ],
            source_format = "json"
        )

    def _parse_dict(
            self,
            data: dict[str, Any]
    ) -> ParsedTable:
        #dict containing a list may be a table stored in an outer json obj
        list_values = [
            value for value in data.values() if isinstance(value,list)
        ]

        if len(list_values) == 1:

            value = list_values[0]

            if all(
                isinstance(item, dict) for item in value
            ):
                return self._parse_list(value)

        #otherwise represent dict as key/val data
        rows = [
            [key, value] for key, value in data.items()
        ]

        return ParsedTable(
            headers = ["key", "value"],
            rows=rows,
            source_format = "json"
        )