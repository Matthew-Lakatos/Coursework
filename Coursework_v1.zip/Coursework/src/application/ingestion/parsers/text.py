import csv
from pathlib import Path

from ...representation.models import ParsedTable
from .base import Parser

class DelimitedParser(Parser):
    def __init__(self, delimiter: str, source_format: str):
        self.delimiter = delimiter
        self.source_format = source_format

    def parse(self, path: Path) -> list[ParsedTable]:
        with path.open(
            "r",
            encoding = "utf-8-sig",
            newline = ""
        ) as file:
            reader = csv.reader(file, delimiter = self.delimiter)

            rows = [
                list(row) for row in reader
            ]

            return [ParsedTable(
                headers=[],
                rows=rows,
                source_format=self.source_format
            )]

class TextParser(Parser):
    def parse(self, path: Path) -> list[ParsedTable]:
        with path.open("r", encoding="utf-8-sig") as file:
            lines = [line.rstrip("\n\r") for line in file]

        rows = [
            [line] for line in lines if line.strip()
        ]

        return [ParsedTable(
            headers=["text"],
            rows=rows,
            source_format = "txt"
        )]