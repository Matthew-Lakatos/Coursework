from abc import ABC, abstractmethod
from pathlib import Path

from ...representation.models import ParsedTable

class Parser(ABC):

    @abstractmethod
    def parse(self, path: Path) -> list[ParsedTable]:
        pass
