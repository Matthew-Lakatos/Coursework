from pathlib import Path

from ...representation.models import ParsedTable
from .base import Parser

class ExcelParser(Parser):

    def parse(self, path: Path) -> list[ParsedTable]:
        try:
            import openpyxl
        except ImportError as exc:
            raise RuntimeError(
                "openpyxl required for xlsx files, install with pip install openpyxl"
            ) from exc

        workbook = openpyxl.load_workbook(
            path,
            read_only = True,
            data_only = True
        )

        tables = []

        try:
            for worksheet in workbook.worksheets:

                rows = [
                    list(row) for row in worksheet.iter_rows(
                        values_only=True
                    )
                ]

                #ignore blank sheets
                if not any(
                    any(
                        value is not None for value in row
                    ) for row in rows
                ):
                    continue

                tables.append(
                    ParsedTable(
                        headers = [],
                        rows=rows,
                        source_format="xlsx",
                        sheet_name=worksheet.title
                    )
                )

        finally:
            workbook.close()
        return tables
    