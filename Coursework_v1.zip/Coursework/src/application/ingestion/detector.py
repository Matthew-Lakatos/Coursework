from dataclasses import dataclass
from enum import Enum
from pathlib import Path
import zipfile
from .errors import(
    BinaryFileError,
    UnsupportedFormatError,
)

class FileFormat(str, Enum):
    CSV = "csv"
    TSV = "tsv"
    TXT = "txt"
    JSON = "json"
    XLSX = "xlsx"
    XLS = "xls"

@dataclass(frozen=True)
class DetectionResult():
    format: FileFormat
    confidence: str

class Detector:
    """
    detection of the actual file format/structure
    treat path endings as suggestions, not truths
    file could be a renamed extension
    """

    def detect(self, path:str | Path) -> DetectionResult:

        path = Path(path)

        if not (path.exists()):
            raise FileNotFoundError(path)
        if not (path.is_file()):
            raise UnsupportedFormatError(f"Not a file: {path}")

        raw = path.read_bytes()

        #XLSX is .zip, normally starts pk
        if raw.startswith(b"PK"):

            if self._looks_like_xlsx(
                path, raw
            ):
                return DetectionResult(FileFormat.XLSX, "high")

        #legacy XLS uses ole signature
        if raw.startswith(b"\xD0\xCF\x11\xE0"):
            return DetectionResult(
                FileFormat.XLS, "high"
            )

        if b"\x00" in raw:
            raise BinaryFileError(f"File appears to be binary, not supported file format {path}")

        try:
            text = raw.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise UnsupportedFormatError(f"File is not valid UTF-8 text or a supported binary file format {path}")

        stripped = text.lstrip()

        #JSON detection
        if (stripped.startswith("[") or stripped.startswith("{")):
            if self._looks_like_json(text):
                return DetectionResult(FileFormat.JSON, "high")

        #apply delimiter (latecy concern)
        first_lines = [
            line for line in text.splitlines() if line.strip()
        ][:10]

        if first_lines:

            if self._has_consistent_delimiter(
                first_lines,
                "\t"
            ):
                return DetectionResult(FileFormat.TSV, "high")

            if self._has_consistent_delimiter(
                first_lines,
                ","
            ):
                return DetectionResult(
                    FileFormat.CSV,
                    "high"
                )

        suffix = path.suffix.lower()

        #medium confidence, extension used as fallback

        if suffix == ".tsv":
            return DetectionResult(FileFormat.TSV, "medium")
        if suffix == ".csv":
            return DetectionResult(FileFormat.CSV, "medium")
        if suffix == ".json":
            return DetectionResult(FileFormat.JSON, "medium")
        if suffix == ".txt":
            return DetectionResult(FileFormat.TXT, "medium")
        if suffix == ".xls":
            return DetectionResult(FileFormat.XLS, "medium")
        if suffix == ".xlsx":
            return DetectionResult(FileFormat.XLSX, "medium")
        raise UnsupportedFormatError(
            f"Could not determine a supported file format: {path}"
        )
    @staticmethod
    def _looks_like_xlsx(
        path: Path,
        raw: bytes
    ) -> bool:
        # i wish templates would work here
        if path.suffix.lower() == ".xlsx":
            return zipfile.is_zipfile(path)
        if not (zipfile.is_zipfile(path)):
            return False

        try:
            with zipfile.ZipFile(path) as archive:

                names = set(archive.namelist())

                return (
                    "[Content_Types].xml" in names
                    and any(name.startswith("xl/") for name in names)
                )
        except zipfile.BadZipFile:
            return False

    @staticmethod
    def _looks_like_json(
        text: str
    ) -> bool:
        import json
        try:
            json.loads(text)
            return True
        except json.JSONDecodeError:
            return False

    @staticmethod
    def _has_consistent_delimiter(lines: list[str], delimiter: str) -> bool:
        counts = [line.count(delimiter) for line in lines]
        if not counts:
            return False

        #set to remove dupes
        return (
            (max(counts) > 0) and (len(set(counts)) == 1)
        )