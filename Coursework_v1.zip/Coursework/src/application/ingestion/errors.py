class IngestionError(Exception):
    """base ingestion error"""

class UnsupportedFormatError(IngestionError):
    """file format could not be identified or supported"""

class MalformedFileError(IngestionError):
    """file format is recognised, but contents are malformed"""

class BinaryFileError(IngestionError):
    """file appears to be binary when text was expected"""

class ExtractionError(IngestionError):
    """data could not be extracted into the common representation"""