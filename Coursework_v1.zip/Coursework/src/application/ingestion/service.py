from pathlib import Path

from ..representation.models import Dataset
from .detector import (
    Detector,
    FileFormat,
)

from .extractor import Extractor
from .parsers import (
    DelimitedParser,
    ExcelParser,
    JSONParser,
    Parser,
    TextParser,
)

class IngestionService:
    """main ingestion pipeline:

    file -> detector -> parser -> extractor -> common data representation
    
    validation deliberately seperate stage after execution"""

    def __init__(self):
        self.detector = Detector()
        self.extractor = Extractor()

    def ingest(self, path: str | Path) -> list[Dataset]:
        path = Path(path)

        detection = self.detector.detect(
            path
        )

        parser = self._get_parser(
            detection.format
        )

        parsed_tables = parser.parse(
            path
        )

        return [
            self.extractor.extract(
                table,
                source = str(path)
            ) for table in parsed_tables
        ]

    def ingest_one(
            self,
            path: str | Path
    ) -> Dataset:
        datasets = self.ingest(path)

        if not datasets:
            raise ValueError(f"No data could be extracted from {path}")

        if len(datasets) > 1:
            raise ValueError(
                "File contains multiple tables, use ingest() instead of ingest_one()"
            )

        return datasets[0]

    def _get_parser(
        self,
        file_format: FileFormat
    ) -> Parser:
        if file_format == FileFormat.CSV:
            return DelimitedParser(
                delimiter = ",",
                source_format = "csv"
            )
        if file_format == FileFormat.TSV:
            return DelimitedParser(
                delimiter="\t",
                source_format = "tsv"
            )
        if file_format == FileFormat.TXT:
            return TextParser()
        if file_format == FileFormat.JSON:
            return JSONParser()
        if file_format == FileFormat.XLSX:
            return ExcelParser()

        #XLS detection exists, but legacy parsing requires seperate implementation
        raise ValueError(
            f"No parser registered for {file_format}"
        )