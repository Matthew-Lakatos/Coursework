from typing import Any

from ..representation.models import (
    Column,
    Dataset,
    ParsedTable,
    Row,
    Schema,
)

from .errors import ExtractionError
from .type_inference import TypeInferer

class Extractor:
    """extract parsed data into common representation, more structural detection can be added later here, e.g. transposed layouts and missing headers and title rows and multiple meaningful tables"""
    def __init__(self):
        self.type_inferer = TypeInferer()

    def extract(
        self,
        table: ParsedTable,
        source: str
    ) -> Dataset:
        if not table.rows:
            return Dataset(
                schema = Schema(columns=()),
                rows=(),
                source=source,
                source_format=table.source_format,
                metadata={
                    "sheet_name": table.sheet_name
                }
            )

        headers = self._get_headers(table)

        if not headers:
            raise ExtractionError("Could not identify any columns")

        #naive assumption to change later: first row is header

        # parsers that already know their headers (e.g. JSON) supply data-only rows,
        # otherwise the first row is the header row
        data_rows = table.rows if table.headers else table.rows[1:]

        width = len(headers)

        normalised_rows = [
            self._normalise_row(
                row,
                width
            ) for row in data_rows
        ]

        columns = []

        for index, header in enumerate(headers):
            values = [row[index] for row in normalised_rows]
            value_type = (
                self.type_inferer.infer_column(
                    values
                )
            )
            nullable = any(
                self._is_empty(value) for value in values
            )
            columns.append(
                Column(
                    name = header,
                    value_type = value_type,
                    nullable=nullable
                )
            )

        rows = tuple(
            Row(
                values=tuple(row)
            ) for row in normalised_rows
        )

        return Dataset(
            schema=Schema(
                columns=tuple(columns)
            ),
            rows=rows,
            source=source,
            source_format = table.source_format,
            metadata={
                "sheet_name": table.sheet_name
            }
        )

    def _get_headers(
        self,
        table: ParsedTable
    ) -> list[str]:
        if table.headers:
            return self._make_unique_headers(
                table.headers
            )

        first_row = table.rows[0]

        headers = [
            str(value).strip()
            if value is not None
            else "" for value in first_row
        ]

        return self._make_unique_headers(
            headers
        )

    @staticmethod
    def _make_unique_headers( #dedup file names
        headers: list[str]
    ) -> list[str]:

        result = []
        used = {}

        for index, header in enumerate(headers, start = 1):
            name = ("" if header is None else str(header)).strip()

            if not name:
                name = f"column_{index}"

            if name in used:
                used[name] += 1

                name = (
                    f"{name}_{used[name]}"
                )

            else:
                used[name] = 1

            result.append(name)

        return result

    @staticmethod
    def _normalise_row(
        row: list[Any],
        width: int
    ) -> list[Any]:
        # missing stated as None rather than deletions/shifts
        if len(row) < width: # normalising the "None" items
            return (
                row
                + [None] * (
                    width - len(row)
                )
            )
        if len(row) > width: #omitting items past index of width
            return row[:width]
        return row

    @staticmethod
    def _is_empty(
        value: Any
    ) -> bool:
        return (
            value is None or (
                isinstance(value, str) and not value.strip()
            )
        )