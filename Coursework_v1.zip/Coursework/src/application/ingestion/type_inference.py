from datetime import date, datetime
from typing import Any

from dateutil.parser import parse as parse_date

from ..representation.models import ValueType

class TypeInferer:
    """basic column type inference, deliberately conservative
     - incorrect type can cause calculations to be wrong"""

    MIN_CONFIDENCE = 0.80

    def infer_column(
            self,
            values: list[Any]
    ) -> ValueType:
        non_empty = [value for value in values if not (self._is_empty(value))]

        if not non_empty:
            return ValueType.UNKNOWN

        if self._confidence(
            non_empty,
            self._is_boolean
        ) >= self.MIN_CONFIDENCE:
            return ValueType.BOOLEAN

        if self._confidence(
            non_empty,
            self._is_numeric
        ) >= self.MIN_CONFIDENCE:
            return ValueType.NUMERIC

        if self._confidence(
            non_empty,
            self._is_date
        ) >= self.MIN_CONFIDENCE:
            return ValueType.DATE

        unique_values = {
            str(value).strip().lower() for value in non_empty
        }

        #repeated vals more likely to represent categories than unrestricted text
        if len(unique_values) <= max(
            20,
            len(non_empty) * 0.20
        ):
            return ValueType.CATEGORICAL

        return ValueType.TEXT

    def _confidence(self, values: list[Any], predicate) -> float:
        matches = sum(1 for value in values if predicate(value))

        return matches / len(values)

    @staticmethod
    def _is_empty(
        value: Any
    ) -> bool:
        return (
            value is None
        ) or (
            isinstance(value, str) and not (value.strip())
        )

    @staticmethod
    def _is_boolean(
        value: Any
    ) -> bool:
        if (isinstance(value, bool)):
            return True
        if (isinstance(value, str)):
            return value.strip().lower() in {
                "true",
                "false",
                "yes",
                "no"
            }
        return False

    @staticmethod
    def _is_numeric(
        value: Any
    ) -> bool:
        if isinstance(value, bool):
            return False
        if isinstance(
            value,
            (int, float)
        ):
            return True
        if not isinstance(value, str):
            return False

        cleaned = (
            value.strip().replace(",", "").replace("%", "")
        )

        if not cleaned:
            return False

        try:
            float(cleaned)
            return True
        except ValueError:
            return False

    @staticmethod
    def _is_date(
        value: Any
    ) -> bool:
        if isinstance(value, (datetime, date)):
            return True
        if not isinstance(value, str):
            return False

        text = value.strip()

        if not text:
            return False

        #avoid normal numbers as dates

        if text.isdigit():
            return False

        try:
            parse_date(text)
            return True
        except (ValueError, OverflowError):
            return False