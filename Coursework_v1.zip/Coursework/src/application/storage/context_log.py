from dataclasses import dataclass
from datetime import datetime
from typing import Any


@dataclass(frozen=True)
class ContextItem:
    id: str
    instance_id: str
    timestamp: datetime
    tags: tuple[str, ...]
    content: Any


class ContextLog:
    """
    persistent context abstraction
    retrieval is tag based rather than sending every previous result into the LLM every time (no RAG)
    """

    def __init__(self):

        self._items: list[
            ContextItem
        ] = []

    def add(
        self,
        item: ContextItem
    ) -> None:

        self._items.append(item)

    def retrieve(
        self,
        instance_id: str,
        tags: set[str] | None = None,
        budget: int = 10
    ) -> list[ContextItem]:

        matching = []

        for item in reversed(
            self._items
        ):

            if item.instance_id != instance_id:
                continue

            if tags is not None:

                if not tags.intersection(
                    item.tags
                ):
                    continue

            matching.append(item)

            if len(matching) >= budget:
                break

        return matching

    def clear_instance(
        self,
        instance_id: str
    ) -> None:

        self._items = [
            item
            for item in self._items
            if item.instance_id != instance_id
        ]