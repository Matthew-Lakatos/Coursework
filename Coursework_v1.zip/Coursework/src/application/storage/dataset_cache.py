from ..representation.models import Dataset


class DatasetCache:
    """
    small in-memory cache for active datasets

    original file is the persistent source.
    cache only for currently active data.
    """

    def __init__(self):

        self._datasets: dict[
            str,
            Dataset
        ] = {}

    def put(
        self,
        key: str,
        dataset: Dataset
    ) -> None:

        self._datasets[key] = dataset

    def get(
        self,
        key: str
    ) -> Dataset:

        if key not in self._datasets:
            raise KeyError(
                f"Dataset not cached: {key}"
            )

        return self._datasets[key]

    def exists(
        self,
        key: str
    ) -> bool:

        return key in self._datasets

    def delete(
        self,
        key: str
    ) -> None:

        self._datasets.pop(
            key,
            None
        )

    def clear(self) -> None:

        self._datasets.clear()