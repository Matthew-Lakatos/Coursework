from pathlib import Path
import shutil


class FileStore:
    """stores original files

    other modules should not directly manipulate the filesystem.
    This class is the abstraction between application logic and storage.
    """

    def __init__(
        self,
        root: str | Path
    ):

        self.root = Path(root)
        self.root.mkdir(
            parents=True,
            exist_ok=True
        )

    def save(
        self,
        source: str | Path,
        file_id: str
    ) -> Path:

        source = Path(source)

        destination = (
            self.root / file_id
        )

        shutil.copy2(
            source,
            destination
        )

        return destination

    def exists(
        self,
        file_id: str
    ) -> bool:

        return (
            self.root / file_id
        ).exists()

    def delete(
        self,
        file_id: str
    ) -> None:

        path = self.root / file_id

        if path.exists():
            path.unlink()

    def get(
        self,
        file_id: str
    ) -> Path:

        path = self.root / file_id

        if not path.exists():
            raise FileNotFoundError(
                file_id
            )

        return path