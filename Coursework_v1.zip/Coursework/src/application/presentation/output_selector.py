from dataclasses import dataclass

from ..analysis.result import AnalysisResult


@dataclass(frozen=True)
class OutputSelection:
    text: bool
    table: bool
    chart: bool


class OutputSelector:
    """
    select an appropriate presentation without exposing unnecessary chart/configuration choices to the user
    """

    def select(
        self,
        result: AnalysisResult
    ) -> OutputSelection:

        if result.operation in {
            "mean",
            "median",
            "range",
            "variance",
            "std_dev",
            "correlation",
            "spearman",
            "covariance"
        }:

            return OutputSelection(
                text=True,
                table=False,
                chart=True
            )

        if result.operation == "compare":

            return OutputSelection(
                text=True,
                table=True,
                chart=True
            )

        if result.operation == "filter":

            return OutputSelection(
                text=True,
                table=True,
                chart=False
            )

        return OutputSelection(
            text=True,
            table=False,
            chart=False
        )