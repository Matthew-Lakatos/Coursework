class UIManager:
    """
    small presentation boundary

    the eventual graphical interface can replace this class.
    The application logic should not need to know how the interface is rendered.
    """

    def show_message(
        self,
        message: str
    ) -> None:

        print(message)

    def show_error(
        self,
        message: str
    ) -> None:

        print(
            f"ERROR: {message}"
        )

    def show_result(
        self,
        result
    ) -> None:

        print()
        print(
            f"Operation: {result.operation}"
        )
        print(
            f"Result: {result.value}"
        )