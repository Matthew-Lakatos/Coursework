import csv
import json
from pathlib import Path
from typing import Any

from ..analysis.result import AnalysisResult


class Exporter:
    """
    export results without coupling the analysis engine to a particular output format
    """

    def export_json(
        self,
        result: AnalysisResult,
        path: str | Path
    ) -> Path:

        path = Path(path)

        path.write_text(
            json.dumps(
                result.as_dict(),
                indent=2,
                default=str
            ),
            encoding="utf-8"
        )

        return path

    def export_csv(
        self,
        result: AnalysisResult,
        path: str | Path
    ) -> Path:

        path = Path(path)

        with path.open(
            "w",
            newline="",
            encoding="utf-8"
        ) as file:

            writer = csv.writer(file)

            writer.writerow([
                "operation",
                "value",
                "source_instance"
            ])

            writer.writerow([
                result.operation,
                result.value,
                result.source_instance
            ])

        return path