from pathlib import Path

from ..analysis.result import AnalysisResult


class Visualizer:
    """basic visual output boundary

    actual GUI/chart integration can be added without changing
    the analysis engine.
    """

    def create_chart_data(
        self,
        result: AnalysisResult
    ) -> dict:

        if isinstance(
            result.value,
            dict
        ):

            return {
                "type": "bar",
                "labels": list(
                    result.value.keys()
                ),
                "values": list(
                    result.value.values()
                )
            }

        return {
            "type": "single_value",
            "value": result.value
        }

    def save_chart_data(
        self,
        result: AnalysisResult,
        path: str | Path
    ) -> Path:

        import json

        path = Path(path)

        data = self.create_chart_data(
            result
        )

        path.write_text(
            json.dumps(
                data,
                indent=2
            ),
            encoding="utf-8"
        )

        return path