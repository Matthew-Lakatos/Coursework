class ValidationError(Exception):
    """base validation error"""


class ValidationIssue:
    def __init__(
        self,
        code: str,
        message: str,
        row: int | None = None,
        column: str | None = None
    ):
        self.code = code
        self.message = message
        self.row = row
        self.column = column

    def __repr__(self) -> str:
        return (
            "ValidationIssue("
            f"code={self.code!r}, "
            f"message={self.message!r}, "
            f"row={self.row!r}, "
            f"column={self.column!r})"
        )
