from dataclasses import dataclass

from ..representation.models import (
    Dataset,
    ValueType,
)
from .errors import ValidationIssue


@dataclass(frozen=True)
class ValidationResult:
    valid: bool
    issues: tuple[ValidationIssue, ...]


class Validator:
    """
    validation before deterministic analysis

    missing values are reported but are not automatically deleted
    
    The original dataset remains available so information not lost
    """

    def validate(
        self,
        dataset: Dataset
    ) -> ValidationResult:

        issues = []

        for column_index, column in enumerate(
            dataset.schema.columns
        ):

            values = dataset.column_values(
                column.name
            )

            for row_index, value in enumerate(
                values
            ):

                if value is None:

                    if not column.nullable:

                        issues.append(
                            ValidationIssue(
                                code="MISSING_REQUIRED",
                                message=(
                                    "Required value is missing."
                                ),
                                row=row_index,
                                column=column.name
                            )
                        )

                    continue

                if (
                    column.value_type
                    == ValueType.NUMERIC
                    and not self._is_numeric(value)
                ):

                    issues.append(
                        ValidationIssue(
                            code="INVALID_NUMERIC",
                            message=(
                                "Value is not numeric."
                            ),
                            row=row_index,
                            column=column.name
                        )
                    )

        return ValidationResult(
            valid=not issues,
            issues=tuple(issues)
        )

    @staticmethod
    def _is_numeric(value) -> bool:

        if isinstance(value, bool):
            return False

        if isinstance(value, (int, float)):
            return True

        if not isinstance(value, str):
            return False

        try:
            float(
                value
                .strip()
                .replace(",", "")
                .replace("%", "")
            )

            return True

        except ValueError:
            return False