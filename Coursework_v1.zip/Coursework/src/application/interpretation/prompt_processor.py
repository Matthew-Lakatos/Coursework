from dataclasses import dataclass
import re


@dataclass(frozen=True)
class Intent:
    operation: str
    parameters: dict[str, str]
    confidence: float
    requires_llm: bool = False


class PromptProcessor:
    """
    basic deterministic prompt interpretation

    the deterministic patterns are deliberately limited.

    An LLM can be introduced later for prompts that cannot be confidently mapped to an explicit operation.


    NOTE: data that is passed inside the prompt instead of attached in file must be extracted from the prompt appropriately -> later feature
    

    """

    def interpret(
        self,
        prompt: str
    ) -> Intent:

        text = prompt.strip().lower()

        # mean
        if (
            "average" in text
            or "mean" in text
        ):

            column = self._extract_column(
                prompt
            )

            if column:
                return Intent(
                    operation="mean",
                    parameters={
                        "column": column
                    },
                    confidence=0.95
                )

        # median
        if "median" in text:

            column = self._extract_column(
                prompt
            )

            if column:
                return Intent(
                    operation="median",
                    parameters={
                        "column": column
                    },
                    confidence=0.95
                )

        # range
        if "range" in text:

            column = self._extract_column(
                prompt
            )

            if column:
                return Intent(
                    operation="range",
                    parameters={
                        "column": column
                    },
                    confidence=0.95
                )

        # variance
        if "variance" in text:

            column = self._extract_column(
                prompt
            )

            if column:
                return Intent(
                    operation="variance",
                    parameters={
                        "column": column
                    },
                    confidence=0.95
                )

        # spearman (checked before the generic correlation pattern)
        if (
            "spearman" in text
            or "rank correlation" in text
        ):

            columns = self._extract_two_columns(
                prompt
            )

            if columns:
                return Intent(
                    operation="spearman",
                    parameters={
                        "column_x": columns[0],
                        "column_y": columns[1]
                    },
                    confidence=0.90
                )

        # correlation
        if "correlation" in text:

            columns = self._extract_two_columns(
                prompt
            )

            if columns:
                return Intent(
                    operation="correlation",
                    parameters={
                        "column_x": columns[0],
                        "column_y": columns[1]
                    },
                    confidence=0.90
                )

        # covariance
        if "covariance" in text:

            columns = self._extract_two_columns(
                prompt
            )

            if columns:
                return Intent(
                    operation="covariance",
                    parameters={
                        "column_x": columns[0],
                        "column_y": columns[1]
                    },
                    confidence=0.90
                )

        # unsupported/ambiguous prompt
        return Intent(
            operation="unknown",
            parameters={},
            confidence=0.0,
            requires_llm=True
        )

    @staticmethod
    def _extract_column(
        prompt: str
    ) -> str | None:

        patterns = (
            # "... for/of/in <column>"
            r"\b(?:for|of|in)\s+(?:the\s+)?['\"]?([^'\"?]+?)['\"]?\s*\??\s*$",
            # "... average/mean/... <column>"
            r"\b(?:average|mean|median|range|variance)\s+(?:the\s+)?['\"]?([^'\"?]+?)['\"]?\s*\??\s*$",
        )

        for pattern in patterns:

            match = re.search(
                pattern,
                prompt.strip(),
                flags=re.IGNORECASE
            )

            if match:
                return match.group(1).strip()

        return None

    @staticmethod
    def _extract_two_columns(
        prompt: str
    ) -> tuple[str, str] | None:

        patterns = (
            # "... between/of/for <x> and <y>"
            r"\b(?:between|of|for)\s+['\"]?([^'\"?]+?)['\"]?"
            r"\s+(?:and|vs\.?|versus)\s+"
            r"['\"]?([^'\"?]+?)['\"]?\s*\??\s*$",
            # "<x> and <y>"
            r"^['\"]?([^'\"?]+?)['\"]?"
            r"\s+(?:and|vs\.?|versus)\s+"
            r"['\"]?([^'\"?]+?)['\"]?\s*\??\s*$",
        )

        for pattern in patterns:

            match = re.search(
                pattern,
                prompt.strip(),
                flags=re.IGNORECASE
            )

            if match:
                return (
                    match.group(1).strip(),
                    match.group(2).strip()
                )

        return None
