from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class LLMResponse:
    text: str
    available: bool


class LLMGateway:
    """
    gateway around a locally hosted LLM

    the rest of the application should not know which model or provider is being used.

    Ollama can be connected here later without changing the deterministic analysis engine.
    """

    def __init__(
        self,
        base_url: str = "http://localhost:11434", #may need to be configured later if blocked on client machine
        model: str = "llama3.2" # may become stale, needs some form of dynamic updating and retention of prior instances for no corruption
    ):

        self.base_url = base_url
        self.model = model

    def available(self) -> bool:

        try:
            import urllib.request

            with urllib.request.urlopen(
                self.base_url,
                timeout=1
            ):
                return True

        except Exception:
            return False

    def interpret(
        self,
        prompt: str,
        context: list[Any] | None = None
    ) -> LLMResponse:

        if not self.available():
            return LLMResponse(
                text="Local LLM is unavailable.",
                available=False
            )

        # Actual model integration remains behind this boundary. No analysis operation depends on it.
        return LLMResponse(
            text=(
                "LLM gateway is available, but model execution "
                "has not yet been configured."
            ),
            available=True
        )