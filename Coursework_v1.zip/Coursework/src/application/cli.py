import argparse

from .analysis import AnalysisEngine
from .ingestion import IngestionService
from .presentation import UIManager
from .validation import Validator

def main():

    parser = argparse.ArgumentParser(
        description = "theDataScientist"
    )

    parser.add_argument(
        "file",
        default=None, # need to link this to the basic financial analysis later
        help="data file to ingest"
    )

    parser.add_argument(
        "--operation",
        default=None,
        help="deterministic operation"
    )

    parser.add_argument(
        "--column",
        default=None,
        help="column used by single-column operation"
    )

    args = parser.parse_args()

    ui = UIManager()

    try:

        ingestion = IngestionService()

        dataset = ingestion.ingest_one(
            args.file
        )

        validation = Validator().validate(
            dataset
        )

        if not (validation.valid):
            ui.show_error("Input validation failed...")

            for issue in validation.issues:
                ui.show_error(
                    f"{issue.code}: "
                    f"{issue.message}: "
                    f"(row: {issue.row}, "
                    f"column: {issue.column})"
                )

            raise SystemExit(1)

        ui.show_message(
            "Ingestion and validation successful."
        )

        ui.show_message(
            f"Rows: {dataset.row_count} "
        )

        ui.show_message(
            f"Columns: {dataset.column_count} "
        )

        if args.operation:

            if not (args.column):

                raise ValueError(
                    "--column is required for this command"
                )

            result = AnalysisEngine().execute(
                args.operation,
                dataset,
                column = args.column
            )

            ui.show_result(
                result
            )

    except Exception as exc:
        ui.show_error(
            str(exc)
        )

        raise SystemExit(1)

if __name__ == "__main__":
    main()