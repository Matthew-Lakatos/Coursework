from dataclasses import dataclass, field
from datetime import datetime
from uuid import uuid4

from ..representation.models import Dataset


@dataclass
class Instance:
    id: str
    name: str
    source: str
    created_at: datetime
    datasets: list[Dataset] = field(
        default_factory=list
    )


class InstanceManager:
    """
    creates and retrieves identifiable analysis instances

    an instance is the persistent identity around a dataset or collection of related datasets (think ChatGPT conversation selection)
    """

    def __init__(self):

        self._instances: dict[
            str,
            Instance
        ] = {}

    def create(
        self,
        dataset: Dataset,
        source: str | None = None,
        name: str | None = None
    ) -> Instance:

        instance_id = str(uuid4())

        instance = Instance(
            id=instance_id,
            name=name or instance_id,
            source=source or dataset.source,
            created_at=datetime.now(),
            datasets=[dataset]
        )

        # atomicity:
        # do not expose instance until construction is complete
        self._instances[
            instance_id
        ] = instance

        return instance

    def retrieve(
        self,
        instance_id: str
    ) -> Instance:

        if instance_id not in self._instances:
            raise KeyError(
                f"Instance does not exist: {instance_id}"
            )

        return self._instances[
            instance_id
        ]

    def delete(
        self,
        instance_id: str
    ) -> None:

        if instance_id not in self._instances:
            raise KeyError(
                f"Instance does not exist: {instance_id}"
            )

        del self._instances[
            instance_id
        ]

    def add_dataset(
        self,
        instance_id: str,
        dataset: Dataset
    ) -> None:

        instance = self.retrieve(
            instance_id
        )

        instance.datasets.append(
            dataset
        )

    def exists(
        self,
        instance_id: str
    ) -> bool:

        return instance_id in self._instances