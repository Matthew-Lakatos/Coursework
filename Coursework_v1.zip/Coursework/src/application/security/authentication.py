from dataclasses import dataclass
import hashlib
import hmac
import secrets


@dataclass(frozen=True)
class User:
    username: str
    password_hash: str


class LocalAuthenticator:
    """
    local authentication

    passwords are never stored directly.
    Only salted password hashes are retained.

    This is intentionally local and simple for the current
    implementation; an external database can be added later
    without changing the authentication interface, may have some trouble preventing source file security though...
    """

    ITERATIONS = 100_000

    def __init__(self):

        self._users: dict[
            str,
            User
        ] = {}

    def create_user(
        self,
        username: str,
        password: str
    ) -> User:

        if username in self._users:
            raise ValueError(
                "Username already exists."
            )

        password_hash = self._hash_password(
            password
        )

        user = User(
            username=username,
            password_hash=password_hash
        )

        self._users[
            username
        ] = user

        return user

    def authenticate(
        self,
        username: str,
        password: str
    ) -> bool:

        user = self._users.get(
            username
        )

        if user is None:
            return False

        salt, stored_hash = (
            user.password_hash.split(
                "$",
                maxsplit=1
            )
        )

        candidate = self._derive_hash(
            password,
            bytes.fromhex(salt)
        )

        return hmac.compare_digest(
            candidate,
            stored_hash
        )

    def _hash_password(
        self,
        password: str
    ) -> str:

        salt = secrets.token_bytes(
            16
        )

        derived = self._derive_hash(
            password,
            salt
        )

        return (
            salt.hex()
            + "$"
            + derived
        )

    def _derive_hash(
        self,
        password: str,
        salt: bytes
    ) -> str:

        derived = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt,
            self.ITERATIONS
        )

        return derived.hex()