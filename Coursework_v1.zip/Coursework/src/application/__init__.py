"""theDataScientist - local teacher data analysis system"""
