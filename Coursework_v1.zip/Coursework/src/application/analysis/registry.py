from .operations import (
    AnalysisOperation,
    CompareMeansOperation,
    CovarianceOperation,
    FilterOperation,
    MeanOperation,
    MedianOperation,
    PearsonCorrelationOperation,
    SpearmanCorrelationOperation,
    RangeOperation,
    StandardDeviationOperation,
    VarianceOperation,
)


class OperationRegistry:
    """registry of deterministic analysis operations

    operations are objects so that the same calculations can be
    reused across many datasets and instances.
    """

    def __init__(self):

        self._operations: dict[
            str,
            AnalysisOperation
        ] = {}

        self.register(
            MeanOperation()
        )

        self.register(
            MedianOperation()
        )

        self.register(
            RangeOperation()
        )

        self.register(
            VarianceOperation()
        )

        self.register(
            StandardDeviationOperation()
        )

        self.register(
            PearsonCorrelationOperation()
        )

        self.register(
            SpearmanCorrelationOperation()
        )

        self.register(
            CovarianceOperation()
        )

        self.register(
            CompareMeansOperation()
        )

        self.register(
            FilterOperation()
        )

    def register(
        self,
        operation: AnalysisOperation
    ) -> None:

        self._operations[
            operation.name
        ] = operation

    def get(
        self,
        name: str
    ) -> AnalysisOperation:

        if name not in self._operations:
            raise KeyError(
                f"Unknown analysis operation: {name}"
            )

        return self._operations[name]

    def names(self) -> tuple[str, ...]:

        return tuple(
            self._operations.keys()
        )