from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class AnalysisResult:
    operation: str
    value: Any
    source_instance: str | None = None
    metadata: dict[str, Any] = field(
        default_factory=dict
    )

    def as_dict(self) -> dict[str, Any]:

        return {
            "operation": self.operation,
            "value": self.value,
            "source_instance": self.source_instance,
            "metadata": self.metadata,
        }