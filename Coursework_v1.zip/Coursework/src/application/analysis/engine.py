from typing import Any

from ..representation.models import Dataset
from .registry import OperationRegistry
from .result import AnalysisResult


class AnalysisEngine:
    """deterministic analysis engine

    this module must not depend on the LLM.

    If a calculation can be represented as a deterministic operation,
    it should happen here rather than inside an LLM response.
    """

    def __init__(
        self,
        registry: OperationRegistry | None = None
    ):

        self.registry = (
            registry
            or OperationRegistry()
        )

    def execute(
        self,
        operation: str,
        dataset: Dataset,
        instance_id: str | None = None,
        **inputs: Any
    ) -> AnalysisResult:

        operation_object = (
            self.registry.get(
                operation
            )
        )

        operation_object.validate(
            dataset,
            **inputs
        )

        value = operation_object.execute(
            dataset,
            **inputs
        )

        return AnalysisResult(
            operation=operation,
            value=value,
            source_instance=instance_id,
            metadata={
                "inputs": inputs
            }
        )