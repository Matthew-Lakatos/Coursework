from statistics import mean, median
from typing import Any

from ...representation.models import Dataset
from .base import AnalysisOperation


class MeanOperation(AnalysisOperation):

    name = "mean"

    def execute(
        self,
        dataset: Dataset,
        column: str,
        **kwargs: Any
    ) -> float:

        values = _numeric_values(
            dataset,
            column
        )

        if not values:
            raise ValueError(
                f"No numeric values in column: {column}"
            )

        return mean(values)


class MedianOperation(AnalysisOperation):

    name = "median"

    def execute(
        self,
        dataset: Dataset,
        column: str,
        **kwargs: Any
    ) -> float:

        values = _numeric_values(
            dataset,
            column
        )

        if not values:
            raise ValueError(
                f"No numeric values in column: {column}"
            )

        return median(values)


class RangeOperation(AnalysisOperation):

    name = "range"

    def execute(
        self,
        dataset: Dataset,
        column: str,
        **kwargs: Any
    ) -> float:

        values = _numeric_values(
            dataset,
            column
        )

        if not values:
            raise ValueError(
                f"No numeric values in column: {column}"
            )

        return max(values) - min(values)


class VarianceOperation(AnalysisOperation):

    name = "variance"

    def execute(
        self,
        dataset: Dataset,
        column: str,
        **kwargs: Any
    ) -> float:

        values = _numeric_values(
            dataset,
            column
        )

        if len(values) < 2:
            return 0.0

        average = mean(values)

        return sum(
            (value - average) ** 2
            for value in values
        ) / len(values)


class StandardDeviationOperation(
    AnalysisOperation
):

    name = "std_dev"

    def execute(
        self,
        dataset: Dataset,
        column: str,
        **kwargs: Any
    ) -> float:

        variance = VarianceOperation().execute(
            dataset,
            column=column
        )

        return variance ** 0.5


def _numeric_values(
    dataset: Dataset,
    column: str
) -> list[float]:

    values = dataset.column_values(
        column
    )

    result = []

    for value in values:

        if value is None:
            continue

        if isinstance(value, bool):
            continue

        if isinstance(value, (int, float)):
            result.append(float(value))
            continue

        if isinstance(value, str):

            try:
                result.append(
                    float(
                        value
                        .strip()
                        .replace(",", "")
                        .replace("%", "")
                    )
                )

            except ValueError:
                # missing/invalid values are excluded from applicable calculations
                continue

    return result