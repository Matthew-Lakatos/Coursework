from typing import Any

from ...representation.models import Dataset
from .base import AnalysisOperation


class FilterOperation(
    AnalysisOperation
):

    name = "filter"

    def execute(
        self,
        dataset: Dataset,
        column: str,
        value: Any,
        **kwargs: Any
    ) -> Dataset:

        index = dataset.schema.index_of(
            column
        )

        rows = tuple(
            row
            for row in dataset.rows
            if row.values[index] == value
        )

        return Dataset(
            schema=dataset.schema,
            rows=rows,
            source=dataset.source,
            source_format=dataset.source_format,
            metadata={
                **dataset.metadata,
                "filtered_by": {
                    column: value
                }
            }
        )