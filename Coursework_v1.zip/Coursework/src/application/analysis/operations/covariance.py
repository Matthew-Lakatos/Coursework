from typing import Any

from ...representation.models import Dataset
from .base import AnalysisOperation


class CovarianceOperation(
    AnalysisOperation
):

    name = "covariance"

    def execute(
        self,
        dataset: Dataset,
        column_x: str,
        column_y: str,
        **kwargs: Any
    ) -> float:

        pairs = []

        x_values = dataset.column_values(
            column_x
        )

        y_values = dataset.column_values(
            column_y
        )

        for x, y in zip(
            x_values,
            y_values
        ):

            try:
                pairs.append(
                    (
                        float(x),
                        float(y)
                    )
                )

            except (
                TypeError,
                ValueError
            ):
                # missing/non-numeric pairs do not participate in the calculation
                continue

        if len(pairs) < 2:
            raise ValueError(
                "At least two numeric pairs are required."
            )

        x_mean = (
            sum(x for x, _ in pairs)
            / len(pairs)
        )

        y_mean = (
            sum(y for _, y in pairs)
            / len(pairs)
        )

        return sum(
            (x - x_mean)
            * (y - y_mean)
            for x, y in pairs
        ) / len(pairs)