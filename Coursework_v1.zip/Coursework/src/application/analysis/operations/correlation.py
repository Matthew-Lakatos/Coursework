from math import sqrt
from typing import Any

from ...representation.models import Dataset
from .base import AnalysisOperation


class PearsonCorrelationOperation(
    AnalysisOperation
):

    name = "correlation"

    def execute(
        self,
        dataset: Dataset,
        column_x: str,
        column_y: str,
        **kwargs: Any
    ) -> float:

        x = _numeric_values(
            dataset,
            column_x
        )

        y = _numeric_values(
            dataset,
            column_y
        )

        if len(x) != len(y):
            raise ValueError(
                "Correlation requires aligned numeric values."
            )

        if len(x) < 2:
            raise ValueError(
                "At least two values are required."
            )

        return _pearson_coefficient(
            x,
            y
        )


class SpearmanCorrelationOperation(
    AnalysisOperation
):
    """spearman rank correlation

    values are converted to ranks (tied values share the average of the
    ranks they span) and pearson's coefficient is taken over those ranks.
    This measures monotonic rather than strictly linear association.
    """

    name = "spearman"

    def execute(
        self,
        dataset: Dataset,
        column_x: str,
        column_y: str,
        **kwargs: Any
    ) -> float:

        x = _numeric_values(
            dataset,
            column_x
        )

        y = _numeric_values(
            dataset,
            column_y
        )

        if len(x) != len(y):
            raise ValueError(
                "Correlation requires aligned numeric values."
            )

        if len(x) < 2:
            raise ValueError(
                "At least two values are required."
            )

        return _pearson_coefficient(
            _ranks(x),
            _ranks(y)
        )


def _pearson_coefficient(
    x: list[float],
    y: list[float]
) -> float:

    mean_x = sum(x) / len(x)
    mean_y = sum(y) / len(y)

    numerator = sum(
        (a - mean_x) * (b - mean_y)
        for a, b in zip(x, y)
    )

    sum_squares_x = sum(
        (a - mean_x) ** 2
        for a in x
    )

    sum_squares_y = sum(
        (b - mean_y) ** 2
        for b in y
    )

    denominator = sqrt(
        sum_squares_x
        * sum_squares_y
    )

    if denominator == 0:
        # zero variance means correlation is undefined
        raise ValueError(
            "Correlation is undefined because "
            "one column has zero variance."
        )

    # guard against floating point drift just outside [-1, 1]
    return max(
        -1.0,
        min(
            1.0,
            numerator / denominator
        )
    )


def _ranks(
    values: list[float]
) -> list[float]:

    order = sorted(
        range(len(values)),
        key=lambda index: values[index]
    )

    ranks = [0.0] * len(values)

    start = 0

    while start < len(order):

        end = start

        # ties share the average of the ranks they occupy
        while (
            end + 1 < len(order)
            and values[order[end + 1]]
            == values[order[start]]
        ):
            end += 1

        average_rank = (start + end) / 2 + 1

        for index in order[start:end + 1]:
            ranks[index] = average_rank

        start = end + 1

    return ranks


def _numeric_values(
    dataset: Dataset,
    column: str
) -> list[float]:

    values = dataset.column_values(
        column
    )

    result = []

    for value in values:

        if value is None:
            continue

        try:
            result.append(
                float(value)
            )

        except (
            TypeError,
            ValueError
        ):
            continue

    return result
