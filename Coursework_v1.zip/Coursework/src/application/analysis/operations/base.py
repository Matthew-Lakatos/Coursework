from abc import ABC, abstractmethod
from typing import Any

from ...representation.models import Dataset


class AnalysisOperation(ABC):

    name: str

    @abstractmethod
    def execute(
        self,
        dataset: Dataset,
        **kwargs: Any
    ) -> Any:
        pass

    def validate(
        self,
        dataset: Dataset,
        **kwargs: Any
    ) -> None:
        pass