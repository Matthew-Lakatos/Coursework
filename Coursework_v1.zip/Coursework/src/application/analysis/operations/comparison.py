from typing import Any

from ...representation.models import Dataset
from .base import AnalysisOperation


class CompareMeansOperation(
    AnalysisOperation
):

    name = "compare"

    def execute(
        self,
        dataset: Dataset,
        column: str,
        group_column: str,
        **kwargs: Any
    ) -> dict[str, float]:

        groups: dict[str, list[float]] = {}

        values = dataset.column_values(
            column
        )

        groups_for_values = dataset.column_values(
            group_column
        )

        for value, group in zip(
            values,
            groups_for_values
        ):

            if value is None or group is None:
                continue

            try:
                numeric_value = float(
                    value
                )

            except (
                TypeError,
                ValueError
            ):
                continue

            key = str(group)

            groups.setdefault(
                key,
                []
            ).append(
                numeric_value
            )

        return {
            group: sum(values) / len(values)
            for group, values in groups.items()
            if values
        }